package swe.PotatoStreamer;

public class User {
	private String id;
	private String pwd;
	
	public void setId(String id)
	{
		this.id = id;
	}
	
	public String getId()
	{
		return id;
	}
	
	public void setPwd(String pwd)
	{
		this.pwd = pwd;
	}
	
	public String getPwd()
	{
		return pwd;
	}
}
