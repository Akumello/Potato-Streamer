package swe.PotatoStreamer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PotatoStreamerApplication 
{
	public static void main(String[] args) {
		SpringApplication.run(PotatoStreamerApplication.class, args);
	}
}
